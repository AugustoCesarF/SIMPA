"""
main.py

API que o SIMPA consome. Recebe as credenciais do aluno (cada aluno usa
as próprias credenciais do AVA), faz o scraping autenticado e devolve
JSON padronizado.

Rodar localmente:
    pip install -r requirements.txt
    uvicorn main:app --reload --port 8000

Endpoint:
    POST /api/ava/dados
    body: { "username": "...", "password": "..." }

⚠️ Segurança mínima pra levar a sério, mesmo em projeto acadêmico:
- Rodar sempre atrás de HTTPS (nunca expor essa API em HTTP puro).
- Não logar/persistir a senha em nenhum lugar (nem em logs de erro).
- Considerar não guardar a senha em cache — só o resultado dos dados.
"""

import time
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from moodle_scraper import MoodleAuthError, fetch_all_data

app = FastAPI(title="SIMPA - Ponte AVA", version="0.1.0")

# Cache simples em memória: evita logar de novo no AVA a cada request.
# Em produção trocar por Redis ou similar.
CACHE_TTL_SECONDS = 60 * 15  # 15 minutos
_cache: dict[str, dict] = {}


class AvaCredentials(BaseModel):
    username: str
    password: str


def _get_cached_or_fetch(username: str, password: str) -> dict:
    now = time.time()
    cached = _cache.get(username)

    if cached and (now - cached["timestamp"] < CACHE_TTL_SECONDS):
        return cached["data"]

    try:
        data = fetch_all_data(username, password)
    except MoodleAuthError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=502, detail=f"Erro ao acessar o AVA: {e}"
        )

    _cache[username] = {"data": data, "timestamp": now}
    return data


@app.post("/api/ava/dados")
def get_dados_ava(creds: AvaCredentials):
    """Retorna cursos e notas do aluno, puxados em tempo (quase) real do AVA."""
    data = _get_cached_or_fetch(creds.username, creds.password)
    return {
        "fonte": "AVA UniEVANGÉLICA (scraping autenticado)",
        "cache_ttl_segundos": CACHE_TTL_SECONDS,
        **data,
    }


@app.get("/api/health")
def health():
    return {"status": "ok"}
