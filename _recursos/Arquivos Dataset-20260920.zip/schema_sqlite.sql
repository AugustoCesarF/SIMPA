PRAGMA foreign_keys = ON;

BEGIN TRANSACTION;

CREATE TABLE cursos (
  curso_id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL,
  grau TEXT NOT NULL,
  total_periodos INTEGER NOT NULL,
  disciplinas_por_periodo INTEGER NOT NULL,
  modalidade TEXT NOT NULL,
  cidade_sede TEXT NOT NULL,
  uf_sede TEXT NOT NULL
);

CREATE TABLE periodos_curriculares (
  periodo_id INTEGER PRIMARY KEY,
  curso_id INTEGER NOT NULL REFERENCES cursos(curso_id),
  numero_periodo INTEGER NOT NULL,
  quantidade_disciplinas INTEGER NOT NULL,
  carga_horaria_prevista INTEGER NOT NULL,
  UNIQUE (curso_id, numero_periodo)
);

CREATE TABLE disciplinas (
  disciplina_id INTEGER PRIMARY KEY,
  periodo_id INTEGER NOT NULL REFERENCES periodos_curriculares(periodo_id),
  codigo TEXT NOT NULL,
  nome TEXT NOT NULL,
  carga_horaria INTEGER NOT NULL,
  tipo TEXT NOT NULL,
  indice_dificuldade_sintetico REAL NOT NULL,
  UNIQUE (codigo)
);

CREATE TABLE cidades (
  cidade_id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL,
  uf TEXT NOT NULL,
  distancia_rodoviaria_aprox_km REAL NOT NULL,
  UNIQUE (nome, uf)
);

CREATE TABLE docentes (
  docente_id INTEGER PRIMARY KEY,
  nome_sintetico TEXT NOT NULL,
  titulacao TEXT NOT NULL,
  regime_trabalho TEXT NOT NULL
);

CREATE TABLE alunos (
  aluno_id INTEGER PRIMARY KEY,
  codigo_academico TEXT NOT NULL,
  nome_sintetico TEXT NOT NULL,
  data_nascimento TEXT NOT NULL,
  genero_autodeclarado TEXT NOT NULL,
  origem_dado TEXT NOT NULL,
  UNIQUE (codigo_academico)
);

CREATE TABLE enderecos_alunos (
  endereco_id INTEGER PRIMARY KEY,
  aluno_id INTEGER NOT NULL REFERENCES alunos(aluno_id),
  cidade_id INTEGER NOT NULL REFERENCES cidades(cidade_id),
  logradouro_sintetico TEXT NOT NULL,
  numero_sintetico INTEGER NOT NULL,
  complemento_sintetico TEXT,
  bairro_sintetico TEXT NOT NULL,
  cep_sintetico TEXT NOT NULL,
  tempo_deslocamento_min INTEGER NOT NULL,
  UNIQUE (aluno_id)
);

CREATE TABLE perfis_socioeconomicos (
  perfil_id INTEGER PRIMARY KEY,
  aluno_id INTEGER NOT NULL REFERENCES alunos(aluno_id),
  data_referencia TEXT NOT NULL,
  renda_pessoal_mensal REAL NOT NULL,
  renda_familiar_mensal REAL NOT NULL,
  pessoas_domicilio INTEGER NOT NULL,
  trabalha INTEGER NOT NULL,
  horas_trabalho_semana INTEGER NOT NULL,
  dependentes INTEGER NOT NULL,
  primeira_geracao_superior INTEGER NOT NULL,
  qualidade_internet TEXT NOT NULL,
  escola_publica_origem INTEGER NOT NULL,
  UNIQUE (aluno_id, data_referencia)
);

CREATE TABLE tipos_bolsa (
  tipo_bolsa_id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL,
  categoria TEXT NOT NULL,
  percentual REAL NOT NULL
);

CREATE TABLE bolsas_alunos (
  bolsa_aluno_id INTEGER PRIMARY KEY,
  aluno_id INTEGER NOT NULL REFERENCES alunos(aluno_id),
  tipo_bolsa_id INTEGER NOT NULL REFERENCES tipos_bolsa(tipo_bolsa_id),
  data_inicio TEXT NOT NULL,
  data_fim TEXT,
  status TEXT NOT NULL
);

CREATE TABLE matriculas_curso (
  matricula_curso_id INTEGER PRIMARY KEY,
  aluno_id INTEGER NOT NULL REFERENCES alunos(aluno_id),
  curso_id INTEGER NOT NULL REFERENCES cursos(curso_id),
  data_ingresso TEXT NOT NULL,
  ano_ingresso INTEGER NOT NULL,
  semestre_ingresso INTEGER NOT NULL,
  periodo_atual INTEGER NOT NULL,
  turno TEXT NOT NULL,
  status TEXT NOT NULL,
  forma_ingresso TEXT NOT NULL,
  data_referencia TEXT NOT NULL,
  UNIQUE (aluno_id, curso_id)
);

CREATE TABLE turmas (
  turma_id INTEGER PRIMARY KEY,
  disciplina_id INTEGER NOT NULL REFERENCES disciplinas(disciplina_id),
  docente_id INTEGER NOT NULL REFERENCES docentes(docente_id),
  ano_letivo INTEGER NOT NULL,
  semestre_letivo INTEGER NOT NULL,
  codigo_turma TEXT NOT NULL,
  turno TEXT NOT NULL,
  modalidade TEXT NOT NULL,
  vagas INTEGER NOT NULL,
  carga_horaria INTEGER NOT NULL,
  UNIQUE (codigo_turma)
);

CREATE TABLE registros_academicos (
  registro_id INTEGER PRIMARY KEY,
  matricula_curso_id INTEGER NOT NULL REFERENCES matriculas_curso(matricula_curso_id),
  turma_id INTEGER NOT NULL REFERENCES turmas(turma_id),
  tentativa INTEGER NOT NULL,
  situacao TEXT NOT NULL,
  nota_n1 REAL NOT NULL,
  nota_n2 REAL,
  nota_projeto REAL,
  nota_parcial REAL,
  nota_final REAL,
  frequencia_percentual REAL,
  faltas_horas INTEGER NOT NULL,
  carga_horaria_cursada INTEGER NOT NULL,
  data_atualizacao TEXT NOT NULL,
  UNIQUE (matricula_curso_id, turma_id, tentativa)
);

CREATE TABLE indicadores_risco (
  indicador_id INTEGER PRIMARY KEY,
  matricula_curso_id INTEGER NOT NULL REFERENCES matriculas_curso(matricula_curso_id),
  data_referencia TEXT NOT NULL,
  media_historica REAL NOT NULL,
  media_periodo_atual REAL NOT NULL,
  frequencia_media REAL NOT NULL,
  reprovacoes INTEGER NOT NULL,
  tendencia_nota_por_periodo REAL NOT NULL,
  score_risco_percentual REAL NOT NULL,
  classificacao_risco TEXT NOT NULL,
  motivos_risco TEXT NOT NULL,
  UNIQUE (matricula_curso_id, data_referencia)
);

CREATE TABLE desfechos_alunos (
  desfecho_id INTEGER PRIMARY KEY,
  matricula_curso_id INTEGER NOT NULL REFERENCES matriculas_curso(matricula_curso_id),
  inicio_janela TEXT NOT NULL,
  fim_janela TEXT NOT NULL,
  evasao_observada INTEGER NOT NULL,
  tipo_desfecho TEXT NOT NULL,
  data_evento_ou_censura TEXT NOT NULL,
  UNIQUE (matricula_curso_id, inicio_janela)
);

COMMIT;
