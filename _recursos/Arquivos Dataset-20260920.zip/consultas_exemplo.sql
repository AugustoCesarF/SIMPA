-- 1) Alunos em maior risco com contexto socioeconômico
SELECT a.codigo_academico, m.periodo_atual, c.nome AS cidade,
       ROUND(p.renda_familiar_mensal / p.pessoas_domicilio, 2) AS renda_per_capita,
       i.score_risco_percentual, i.motivos_risco
FROM indicadores_risco i
JOIN matriculas_curso m ON m.matricula_curso_id = i.matricula_curso_id
JOIN alunos a ON a.aluno_id = m.aluno_id
JOIN perfis_socioeconomicos p ON p.aluno_id = a.aluno_id
JOIN enderecos_alunos e ON e.aluno_id = a.aluno_id
JOIN cidades c ON c.cidade_id = e.cidade_id
ORDER BY i.score_risco_percentual DESC
LIMIT 20;

-- 2) Nota e frequência médias por disciplina
SELECT d.codigo, d.nome, ROUND(AVG(r.nota_final), 2) AS media_nota, ROUND(AVG(r.frequencia_percentual), 2) AS media_frequencia
FROM registros_academicos r
JOIN turmas t ON t.turma_id = r.turma_id
JOIN disciplinas d ON d.disciplina_id = t.disciplina_id
WHERE r.nota_final IS NOT NULL
GROUP BY d.disciplina_id, d.codigo, d.nome
ORDER BY media_nota;

-- 3) Taxa sintética de evasão por cidade
SELECT c.nome, COUNT(*) AS alunos, ROUND(100.0 * AVG(o.evasao_observada), 1) AS taxa_evasao_pct
FROM desfechos_alunos o
JOIN matriculas_curso m ON m.matricula_curso_id = o.matricula_curso_id
JOIN enderecos_alunos e ON e.aluno_id = m.aluno_id
JOIN cidades c ON c.cidade_id = e.cidade_id
GROUP BY c.cidade_id, c.nome
HAVING COUNT(*) >= 3
ORDER BY taxa_evasao_pct DESC;

-- 4) Comparação entre bolsistas e não bolsistas
SELECT CASE WHEN b.aluno_id IS NULL THEN 'NAO_BOLSISTA' ELSE 'BOLSISTA' END AS grupo,
       COUNT(DISTINCT m.aluno_id) AS alunos, ROUND(AVG(i.media_historica), 2) AS media_historica,
       ROUND(AVG(i.frequencia_media), 2) AS frequencia_media, ROUND(100.0 * AVG(o.evasao_observada), 1) AS evasao_pct
FROM matriculas_curso m
LEFT JOIN bolsas_alunos b ON b.aluno_id = m.aluno_id AND b.status = 'ATIVA'
JOIN indicadores_risco i ON i.matricula_curso_id = m.matricula_curso_id
JOIN desfechos_alunos o ON o.matricula_curso_id = m.matricula_curso_id
GROUP BY grupo;

-- 5) Qualidade: nulos e valores fora das faixas esperadas
SELECT
  SUM(CASE WHEN nota_final IS NULL AND situacao <> 'EM_CURSO' THEN 1 ELSE 0 END) AS notas_finais_ausentes_indevidas,
  SUM(CASE WHEN frequencia_percentual IS NULL THEN 1 ELSE 0 END) AS frequencias_ausentes,
  SUM(CASE WHEN nota_n1 < 0 OR nota_n1 > 100 THEN 1 ELSE 0 END) AS notas_n1_fora_faixa
FROM registros_academicos;
