# Relatório de validação do dataset SIMPA

## Resultado

Validação concluída com sucesso. As chaves primárias são únicas, todas as chaves estrangeiras apontam para registros existentes, os valores acadêmicos respeitam as faixas definidas e os 15 CSVs foram importados integralmente em uma base SQLite de teste sem violações referenciais.

## Cobertura estrutural

- 120 alunos, distribuídos igualmente: 15 alunos em cada um dos 8 períodos.
- 40 disciplinas: exatamente 5 por período.
- 320 turmas ofertadas entre 2023-1 e 2026-2.
- 2.949 registros acadêmicos, incluindo repetições de disciplina.
- 600 registros do semestre corrente com nota final nula por estarem em andamento.
- 3 notas parciais e 12 frequências ausentes de modo intencional, para exercícios de qualidade e tratamento de dados.
- 15 cidades; 57 alunos residem fora de Anápolis.
- 53 alunos possuem bolsa ou financiamento ativo.

## Variável-alvo e risco

- Permanência: 100 alunos (83,3%).
- Evasão sintética na janela de 12 meses: 20 alunos (16,7%).
- Taxa de evasão por classe de risco: baixo 4,2%; moderado 20,0%; alto 20,0%; crítico 50,0%.

## Relações estatísticas intencionais

Correlação de Pearson com a variável `evasao_observada`:

- média do período atual: -0,532;
- frequência média: -0,289;
- tendência de notas: -0,190;
- reprovações: +0,551;
- horas de trabalho: +0,206;
- tempo de deslocamento: +0,221;
- score heurístico de risco: +0,514.

A correlação entre nota parcial e frequência é +0,307. Bolsistas apresentam 5,7% de evasão sintética, contra 25,4% entre não bolsistas. Essas relações contêm ruído e não devem ser interpretadas como causalidade.

## Cuidados para modelagem

- Não use `score_risco_percentual`, `classificacao_risco` ou `motivos_risco` como entrada ao tentar prever `evasao_observada`; isso produziria vazamento de informação.
- A base é pequena e desbalanceada. Use divisão estratificada, validação cruzada e métricas além de acurácia.
- Categorias com poucas observações, especialmente algumas cidades, geram taxas instáveis.
- Todos os dados pessoais, endereços e desfechos são sintéticos.
